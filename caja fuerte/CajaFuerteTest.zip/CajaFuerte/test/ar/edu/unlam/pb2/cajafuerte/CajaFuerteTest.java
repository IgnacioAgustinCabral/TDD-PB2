package ar.edu.unlam.pb2.cajafuerte;

import org.junit.Assert;
import org.junit.Test;

public class CajaFuerteTest {
	@Test
	public void alCrearUnaCajaFuerteDeberiaEstarAbierta() {
		// Preparacion

		// Ejecucion
		CajaFuerte caja = cuandoCreoUnaCajaFuerte();

		laCajaFuerteEstaAbierta(caja);

		// Contrastacion
	}

	@Test
	public void alCerrarlaDeberiaQuedarCerrada() {
		// preparacion
		CajaFuerte caja = dadoQueExisteUnaCajaFuerte();
		// ejecucion
		cuandoCierroLaCajaFuerte(caja);
		// contrastacion
		entoncesLaCajaFuerteEstaCerrada(caja);
	}
	
	@Test
	public void alAbrirLaCajaFuerteConElCodigoDeCierreDeberiaAbrirse(){
		
		//Preparacion
		CajaFuerte caja = dadoQueExisteUnaCajaFuerte();
		dadoQueCierroLaCajaFuerte(caja, codigoDeApertura);		
		//Ejecucion
		cuandoAbroLaCajaFuerte(caja, codigoDeApertura);
		//Contrastacion
		entoncesLaCajaFuerteEstaAbierta(caja);
		
		
	}

	private void dadoQueCierroLaCajaFuerte(CajaFuerte caja, Codigo codigo) {
		
		
	}

	private void entoncesLaCajaFuerteEstaCerrada(CajaFuerte caja) {
		Assert.assertEquals(false, caja.estaAbierta());

	}

	private void cuandoCierroLaCajaFuerte(CajaFuerte caja) {
		caja.cerrar();

	}

	private CajaFuerte dadoQueExisteUnaCajaFuerte() {

		return new CajaFuerte();
	}

	private void laCajaFuerteEstaAbierta(CajaFuerte caja) {

		Assert.assertTrue(caja.estaAbierta());

	}

	private CajaFuerte cuandoCreoUnaCajaFuerte() {

		return new CajaFuerte();
	}
}
