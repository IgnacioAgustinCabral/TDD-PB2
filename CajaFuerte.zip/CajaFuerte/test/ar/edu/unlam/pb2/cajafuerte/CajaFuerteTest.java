package ar.edu.unlam.pb2.cajafuerte;

import org.junit.Assert;
import org.junit.Test;

public class CajaFuerteTest {
	public static final int CODIGO_DE_APERTURA = 123;

	@Test
	public void alCrearUnaCajaFuerteDeberiaEstarAbierta() {
		// Preparacion

		// Ejecucion
		CajaFuerte caja = cuandoCreoUnaCajaFuerte();

		laCajaFuerteEstaAbierta(caja);

		// Contrastacion
	}

//	@Test
//	public void alCerrarlaDeberiaQuedarCerrada() {
//		// preparacion
//		CajaFuerte caja = dadoQueExisteUnaCajaFuerte();
//		// ejecucion
//		cuandoCierroLaCajaFuerte(caja);
//		// contrastacion
//		entoncesLaCajaFuerteEstaCerrada(caja);
//	}
	
	@Test
	public void alAbrirLaCajaFuerteConElCodigoDeCierreDeberiaAbrirse(){
		
		//Preparacion
		CajaFuerte caja = dadoQueExisteUnaCajaFuerte();
		dadoQueCierroLaCajaFuerte(caja, CODIGO_DE_APERTURA);		
		//Ejecucion
		cuandoAbroLaCajaFuerte(caja, CODIGO_DE_APERTURA);
		//Contrastacion
		entoncesLaCajaFuerteEstaAbierta(caja);
		
		
	}
	
	@Test
	public void alAbrirLaCajaFuerteConUnCodigoErroneoNoDeberiaAbrirse() {
		//Preparacion
		CajaFuerte caja = dadoQueExisteUnaCajaFuerte();
		dadoQueCierroLaCajaFuerte(caja, CODIGO_DE_APERTURA);		
		//Ejecucion
		cuandoAbroLaCajaFuerte(caja, CODIGO_DE_APERTURA+5);
		//Contrastacion
		entoncesLaCajaFuerteEstaCerrada(caja);
	}
	
/////////////////////////////////////////////////////////////////////////
	
/////////////////////////////////////////////////////////////////////////
	

//	private void cuandoCierroLaCajaFuerte(CajaFuerte caja) {
//		caja.cerrar();
//
//	}

	private CajaFuerte dadoQueExisteUnaCajaFuerte() {

		return new CajaFuerte();
	}

	private void laCajaFuerteEstaAbierta(CajaFuerte caja) {

		Assert.assertTrue(caja.estaAbierta());

	}

	private CajaFuerte cuandoCreoUnaCajaFuerte() {

		return new CajaFuerte();
	}
	//////////////////////////// TEST alAbrirLaCajaFuerteConElCodigoDeCierreDeberiaAbrirse
	private void entoncesLaCajaFuerteEstaAbierta(CajaFuerte caja) {
		
		Assert.assertEquals(true, caja.estaAbierta());
		
	}

	private void cuandoAbroLaCajaFuerte(CajaFuerte caja, Integer codigoDeApertura) {
		caja.abrir(codigoDeApertura);
		
	}

	private void dadoQueCierroLaCajaFuerte(CajaFuerte caja, Integer codigoDeApertura) {
		caja.cerrar(codigoDeApertura);
		
	}
	//////////////////////////// TEST alAbrirLaCajaFuerteConUnCodigoErroneoNoDeberiaAbrirse
	private void entoncesLaCajaFuerteEstaCerrada(CajaFuerte caja) {
		Assert.assertEquals(false, caja.estaAbierta());

	}
}
